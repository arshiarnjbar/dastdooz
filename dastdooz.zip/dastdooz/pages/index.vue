<template>
  <div>
    <v-carousel
      cycle
      height="250"
      hide-delimiter-background
      show-arrows-on-hover
    >
      <v-carousel-item v-for="(slide, i) in slides" :key="i">
        <v-sheet :color="colors[i]" height="80%">
          <v-row class="fill-height" align="center" justify="center">
            <div class="display-2">{{ slide }} Slide</div>
          </v-row>
        </v-sheet>
      </v-carousel-item>
    </v-carousel>
    <v-container>
      <v-row justify="center" align="center">
        <v-col v-for="card in cards" :key="card.title" cols="6" md="3" lg="4">
          <v-card color="#385F73" dark>
            <v-img
              src="https://images.unsplash.com/photo-1592492135673-55966d3b541a?ixlib=rb-1.2.1&q=80&fm=jpg&crop=entropy&cs=tinysrgb&dl=elena-mozhvilo-lfeSPLBxcKU-unsplash.jpg&w=640"
              lazy-src="https://images.unsplash.com/photo-1592492135673-55966d3b541a?ixlib=rb-1.2.1&q=80&fm=jpg&crop=entropy&cs=tinysrgb&dl=elena-mozhvilo-lfeSPLBxcKU-unsplash.jpg&w=640"
              aspect-ratio="1"
              height="200"
              class="grey lighten-2"
            >
              <template v-slot:placeholder>
                <v-row class="fill-height ma-0" align="center" justify="center">
                  <v-progress-circular
                    indeterminate
                    color="grey lighten-5"
                  ></v-progress-circular>
                </v-row>
              </template>
            </v-img>
            <v-card-title class="headline"> Unlimited music now</v-card-title>

            <v-card-subtitle
              >Li sten to your favorite artists and albums whenever and
              wherever, online and offline.</v-card-subtitle
            >

            <v-card-actions>
              <v-btn text> Listen Now </v-btn>
            </v-card-actions>
          </v-card>
        </v-col>
      </v-row>
    </v-container>
  </div>
</template>

<script>
export default {
  data() {
    return {
      colors: [
        'indigo',
        'warning',
        'pink darken-2',
        'red lighten-1',
        'deep-purple accent-4',
      ],
      slides: ['First', 'Second', 'Third', 'Fourth', 'Fifth'],
      cards: [
        { title: 'متفکر', content: 'نقاشی با رنگ فلان' },
        { title: 'متعصب', content: 'روز درخت کاری مبارک' },
        { title: 'متعصب', content: 'روز درخت کاری مبارک' },
        { title: 'متعصب', content: 'روز درخت کاری مبارک' },

        { title: 'متعصب', content: 'روز درخت کاری مبارک' },

        { title: 'متعصب', content: 'روز درخت کاری مبارک' },
      ],
    }
  },
}
</script>
<style scoped>
.v-card {
  direction: rtl;
}
</style>
