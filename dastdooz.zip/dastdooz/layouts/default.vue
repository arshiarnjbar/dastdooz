<template>
  <v-app light>
    <v-system-bar color="primary" lights-out>
      <v-spacer></v-spacer>
      <v-icon>mdi-wifi-strength-4</v-icon>
      <v-icon>mdi-signal-cellular-outline</v-icon>
      <v-icon>mdi-battery</v-icon>
      <span>12:30</span>
    </v-system-bar>
    <v-main>
      <nuxt />
    </v-main>

    <v-bottom-navigation v-model="value" dark shift fixed>
      <v-btn
        v-for="(item, i) in items"
        :key="i"
        :to="item.to"
        :value="item.value"
        router
        exact
      >
        <span v-text="item.title"></span>
        <v-icon>mdi-{{ item.icon }}</v-icon>
      </v-btn>
    </v-bottom-navigation>
  </v-app>
</template>

<script>
export default {
  data() {
    return {
      value: 'dastdooz',
      clipped: false,
      miniVariant: false,
      right: true,
      rightDrawer: false,
      title: 'Vuetify.js',
      items: [
        {
          icon: 'shopping-outline',
          value: 'dastdooz',
          title: 'دست دوز',
          to: '/',
        },
        {
          icon: 'magnify',
          value: 'shop',
          title: 'فروشگاه',
          to: '/inspire',
        },
        {
          icon: 'cart-outline',
          value: 'cart',
          title: 'سبد خرید',
          to: '/cart',
        },
        {
          icon: 'emoticon-happy-outline',
          value: 'bookmarks',
          title: 'پسندیده',
          to: '/bookmarks',
        },
      ],
    }
  },
}
</script>
<style scoped>
* {
  font-family: vazir;
}
</style>
